const book = require('../model/model');
let data = [];

const defaultpath = (req, res) => {


    res.render('index');

}

const addDoc = (req, res) => {
    console.log(req.body);

    const myTodo = new todo({
        task : req.body.task
    })

    console.log('list', myTodo);

    res.redirect('/');
}

const editTodo = (req, res) => {
    let edit = data.find((d) => {
        return d.id == req.params.id
    })

    console.log(edit);

    res.render('edit');
}

module.exports = {defaultpath, addDoc, editTodo}