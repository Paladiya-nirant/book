const express = require('express');
let app = express();
const body_parser = require('body-parser');
const mongoose = require('./db/todomodel');

let route = require('./routes/route');


app.set('view engine', 'ejs');

app.use(body_parser.urlencoded({extended:true}));

app.use('/index',route);

mongoose

app.listen(4000,() => {

    console.log('server running 4000...');

});