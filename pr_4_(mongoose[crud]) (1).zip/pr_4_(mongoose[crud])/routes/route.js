const express = require('express');
const route = express();
const task = require('../controllers/controllers');


route.get('/',task.defaultpath);

route.post('/addDoc', task.addDoc);

route.post('/editTodo',task.editTodo)


module.exports = route;
